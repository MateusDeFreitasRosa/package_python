# -*- coding: utf-8 -*-
"""
Created on Thu Jun 24 14:29:57 2021

@author: mateu
"""
from setuptools import setup

setup(
    name='package_python',
    packages=['package_python'],
    description='My first package_test_py',
    version='1.0.0',
    url='https://github.com/MateusDeFreitasRosa/package_python',
    author='Mateus de Freitas Rosa',
    author_email='mateusfreitasrosa@hotmail.com',
    keywords=['pip'],
    license='MIT'
)